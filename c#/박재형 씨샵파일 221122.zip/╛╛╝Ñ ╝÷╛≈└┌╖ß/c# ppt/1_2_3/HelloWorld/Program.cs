﻿

using System;
using System.Collections.Generic;

namespace HelloWorld
{

    class person
    {
        int age;
        void printAge()
        {

        }
    }
    class Animal
    {
        string name;
        void printName()
        {

        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            //printf~~~~
            Console.WriteLine("\"Hello World!\"");
            Console.Write("\n Hi there");
            //string Hello = "Hello";
            //string World = "World";
            //Console.WriteLine(""+Hello+World+"");
            Console.WriteLine(123);
            Console.WriteLine( Math.Abs(-100));
            string Hey = "Hey" + " theree!!!";
            Console.WriteLine(Hey);

            int hasSpace = 100;
            int has_space = 100;
            int 김완수 = 10;
            int 김현우 = 1;
            Console.WriteLine(김완수 + 김현우);

        }

    }
}

//namespace MyNamespace
//{
//    class Program
//    {

//        int abc = 0;
//    }
//}
