﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMyCSharp02_01
{
    public struct Student
    {
        public int Age;
        public string Name;
        public double eye;
    }
}
