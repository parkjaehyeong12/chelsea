﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 연습5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (char a = 'a'; a <= 'z'; a++)
            {
                Console.WriteLine(a+"재형 ");
            }
        }
    }
}
