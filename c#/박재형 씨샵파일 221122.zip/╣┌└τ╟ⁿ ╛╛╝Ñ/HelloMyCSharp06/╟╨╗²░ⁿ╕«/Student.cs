﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 학생관리
{
    public class Student
    {
        public string name;
        public int grade;
    }
}
